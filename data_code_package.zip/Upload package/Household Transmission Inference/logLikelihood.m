function [funval, data] = logLikelihood_HH(para, data)

INFECTED = 1;
UNINFECTED = 2;
PRIMARY = 3;

dt = data.dt;

ageVec = 0:100;
ageSuscepPartition = data.ageSuscepPartition;
if (data.ageSusceptibilityType==1 || data.ageSusceptibilityType==2)
    ageSusceptibility = [para(1) para(1) 1 1];
    lastIndex = 1;
elseif (data.ageSusceptibilityType==3 || data.ageSusceptibilityType==4)
    ageSusceptibility = [para(1:2) 1 1];
    lastIndex = 2;
end
if (strcmp(data.interpolationMethod, 'pchip'))
    ageSusceptibilityRef = pchip(ageSuscepPartition, ageSusceptibility, ageVec);
else
    ageSusceptibilityRef = interp1(ageSuscepPartition, ageSusceptibility, ageVec);
end
data.ageSusceptibility = ageSusceptibility;

if (data.ageInfectiousnessType==1)
    ageInfectiousness = [para(lastIndex+1) 1 1];
elseif (data.ageInfectiousnessType==2)
    ageInfectiousness = [para(lastIndex+1) 1];
end

ageInfectPartition = data.ageInfectPartition;
lastIndex = lastIndex+1;
if (strcmp(data.interpolationMethod, 'pchip'))
    ageInfectiousnessRef = pchip(ageInfectPartition, ageInfectiousness, ageVec);
else
    ageInfectiousnessRef = interp1(ageInfectPartition, ageInfectiousness, ageVec);
end
data.ageInfectiousness = ageInfectiousness;

sexSusceptibility = [para(lastIndex+1) 1];
sexInfectiousness = [para(lastIndex+2) 1];
lastIndex = lastIndex+2;

betaVec = para(lastIndex+(1:data.numBeta));
bv = lastIndex+(1:numel(betaVec));
lastIndex = lastIndex+numel(betaVec);

% numStages = 1+para(lastIndex+1);
muInf = para(lastIndex+1);
modeMeanRatio = exp(-para(lastIndex+2));
rhoInf = para(lastIndex+3);
primaryAnhuiBeta = lastIndex+4;
relativeBetaAnhui = para(lastIndex+4);
relativeBetaBeforeLockdown = para(lastIndex+5);

if (~isempty(data.prevPara))
    diff_beta = abs(data.prevPara(bv)-para(bv));
    changeBeta = any(diff_beta>1e-10);
end

vv = lastIndex+(1:3);

timeMax = 200;
UNCONDITIONAL = ceil(data.maxIncubationTime)+10;
presymInfectiousness = 0;
meanTg = 0;
incubationVec = 0:ceil(data.maxIncubationTime);
cdf_Incub = logncdf([incubationVec incubationVec(end)+1], data.mu_Incub, data.sigma_Incub);
pmf_Incub = cdf_Incub(2:end)-cdf_Incub(1:end-1);

incubationVec = incubationVec+0.5;

infectiousnessProfile{UNCONDITIONAL} = zeros(1,timeMax/dt);
for ii=1:numel(incubationVec)
    incubTime = incubationVec(ii);
    if (data.infectiousnessType==1)
        infStartTime = muInf*incubTime;
        infPeakTime = max(dt, rhoInf*incubTime);
    end
    if (data.gammaGT)
        aa_Inf = 1/(1-modeMeanRatio);
        bb_Inf = infPeakTime/(aa_Inf-1);
        xmax = gaminv(1-1e-3, aa_Inf, bb_Inf);
    else
        bb_Inf_sq = -2/3*log(modeMeanRatio);
        bb_Inf = sqrt(bb_Inf_sq);
        aa_Inf = bb_Inf_sq+log(infPeakTime);
        xmax = logninv(1-1e-3, aa_Inf, bb_Inf);
    end
    tv = 0:dt:xmax;
    if (data.gammaGT)
        xx = gamcdf(tv, aa_Inf, bb_Inf);
    else
        xx = logncdf(tv, aa_Inf, bb_Inf);
    end
    xx = xx(2:end)-xx(1:end-1);
    xx = xx/sum(xx);
    xx = [zeros(1, floor(infStartTime/dt)) xx];
    
    xx = xx(1:min(timeMax/dt,numel(xx)));
    infectiousnessProfile{ii} = xx;
    
    nn = numel(xx);
    infectiousnessProfile{UNCONDITIONAL}(1:nn) = infectiousnessProfile{UNCONDITIONAL}(1:nn)+xx*pmf_Incub(ii);
    if (data.gammaGT)
        presymInfectiousness = presymInfectiousness+gamcdf(incubTime-infStartTime, aa_Inf, bb_Inf)*pmf_Incub(ii);
        [mm, ~] = gamstat(aa_Inf, bb_Inf);
    else
        presymInfectiousness = presymInfectiousness+logncdf(incubTime-infStartTime, aa_Inf, bb_Inf)*pmf_Incub(ii);
        [mm, ~] = lognstat(aa_Inf, bb_Inf);
    end
    meanTg = meanTg+(mm+infStartTime)*pmf_Incub(ii);
    data.prev_meanTg = meanTg;
end
data.prev_infectiousnessProfile = infectiousnessProfile;
data.prev_meanTg = meanTg;

SI_vec = min(data.SI(:)):max(data.SI(:));
[SI_pdf, SI_cdf] = calc_pdf_SI(SI_vec, muInf, rhoInf, modeMeanRatio, data);
logL_SI = sum(loge(SI_pdf(data.serialInterval_exact-SI_vec(1)+1)));
logL_SI = logL_SI+sum(loge(SI_cdf(data.serialInterval_range(:,2)-SI_vec(1)+1)-SI_cdf(data.serialInterval_range(:,1)-SI_vec(1)+1)));
data.prev_logL_SL = logL_SI;

if (any(SI_cdf(2:end)-SI_cdf(1:end-1)<0))
    disp('error in calc_SI')
    pause;
end


logL_total = zeros(1,numel(data.clusterList));
for clusterIndex=1:numel(data.clusterList)
    clusterID = data.clusterList(clusterIndex);
    
    if (clusterID==26001)
        continue;
    end
    if (data.cluster(clusterID).size>data.maxClusterSize)
        continue;
    end
    if (data.singlePrimaryCase && numel(data.cluster(clusterID).primaryList)>1)
        continue;
    end
    if (~isempty(data.prevPara) && data.fullCalc==false)
        if (changeBeta && diff_beta(min(end,data.cluster(clusterID).size-1))<1e-100 || ...
                (abs(data.prevPara(primaryAnhuiBeta)-para(primaryAnhuiBeta))>0 && clusterID<2e4))
            logL_total(clusterIndex) = data.cluster(clusterID).logLikelihood;
            continue;
        end
    end
    thisCluster = data.cluster(clusterID);
    numIndexCases = numel(thisCluster.primaryList);
    
    thisCluster.beta = betaVec(min(end,thisCluster.size-1));
    if (clusterID>2e4)  % different beta for anhui
        thisCluster.beta = relativeBetaAnhui*thisCluster.beta;
    end
    
    primaryInfectionTime = thisCluster.primaryInfectionTime;
    primaryIncubationPMF_log = thisCluster.primaryIncubationPMF_log;
    thisCluster.likelihoodConditional = zeros(1,size(primaryInfectionTime,1));
    
    for kkk=1:size(primaryInfectionTime,1)
        if (isempty(data.prevPara))
            for jj=1:numIndexCases
                if (thisCluster.primary(jj).onsetDate>0)
                    thisCluster.logL(kkk,jj,PRIMARY) = primaryIncubationPMF_log(kkk,jj);
                else
                    thisCluster.logL(kkk,jj,PRIMARY) = loge(logncdf(thisCluster.primary(jj).quarantineDate-primaryInfectionTime(kkk,jj)+0.5, data.mu_Incub, data.sigma_Incub));
                end
            end
        end
        
        %%%%%%%%%%%% Uninfected contacts
        for contactType=INFECTED:UNINFECTED
            for jj=1:numel(thisCluster.contactList{contactType})
                thisContact = thisCluster.contact{contactType}(jj);
                if (isnan(thisContact.age) || isnan(thisContact.gender))
                    continue;
                end
                
                contactDates = thisContact.contactDates;
                nn = max(contactDates(:));
                thisContact.FOI = zeros(size(contactDates,1), 2*nn/dt);
                
                for primary_ii=1:size(contactDates,1)
                    thisContactDates = contactDates(primary_ii,:);
                    thisInfectionTime = primaryInfectionTime(kkk,primary_ii);
                    if (thisInfectionTime>thisContactDates(2))
                        continue
                    end
                    
                    thisPrimary = thisCluster.primary(primary_ii);
                    if (thisPrimary.onsetDate>0)
                        fI = 1+floor(thisCluster.primaryIncubation(kkk,primary_ii));
                        infectionTimeIndex = ceil(thisInfectionTime/dt);
                        thisPrimaryFOI = [zeros(1, infectionTimeIndex) infectiousnessProfile{fI}];
                    else
                        thisPrimaryFOI = [zeros(1, infectionTimeIndex) infectiousnessProfile{UNCONDITIONAL}];
                    end
                    multiplierFOI = thisCluster.beta*sexInfectiousness(thisPrimary.gender)*...
                        ageSusceptibilityRef(ceil(thisContact.age))*sexSusceptibility(thisContact.gender);
                    if (data.ageInfectiousnessType>0)
                        multiplierFOI = multiplierFOI*ageInfectiousnessRef(ceil(thisPrimary.age));
                    end
                    if (floor(thisInfectionTime)>thisContactDates(1))
                        thisContactDates(1) = thisInfectionTime;
                    end
                    if (contactType==INFECTED && floor(thisContact.onsetDate)<thisContactDates(2))
                        thisContactDates(2) = floor(thisContact.onsetDate);
                    end
                    ct = thisContactDates(1)/dt:min(numel(thisPrimaryFOI)-1,thisContactDates(2)/dt);
                    thisContact.FOI(primary_ii,1+ct) = thisPrimaryFOI(1+ct)*multiplierFOI;
                    fI = find(ct<thisCluster.timeLockdown/dt, 1, 'last');
                    if (~isempty(fI))
                        thisContact.FOI(primary_ii,1+ct(1:fI)) = thisContact.FOI(primary_ii,1+ct(1:fI))*relativeBetaBeforeLockdown;
                    end
                end
                thisFOI = sum(thisContact.FOI,1);
                thisCumFOI = [0 cumsum(thisFOI)];
                
                if (contactType==UNINFECTED)
                    thisCluster.logL(kkk,jj,contactType) = -thisCumFOI(end);
                else
                    onsetDate = thisContact.onsetDate;
                    incubationPMF = thisContact.incubationPMF;
                    thisLikelihood = 0;
                    
                    fI = find(thisFOI>0);
                    if (thisContact.quarantineDate<0)
                        disp('error in quarantine date')
                        pause
                    end
                    if (~isempty(fI))
                        incubIndex = fI(1);
                        for tt=fI(1):fI(end)
                            xx = (1-exp(-thisFOI(tt)))*exp(-thisCumFOI(max(1,tt-1)));
                            if (onsetDate>0)
                                if (incubIndex>numel(incubationPMF))
                                    break;
                                else
                                    xx = xx*incubationPMF(incubIndex);
                                end
                            end
                            thisLikelihood = thisLikelihood+xx;
                            incubIndex = incubIndex+1;
                        end
                    end
                    thisCluster.logL(kkk,jj,contactType) = loge(thisLikelihood);
                end
            end
        end
        
        if (isempty(data.prevPara))
            thisCluster.logL_base(kkk) = sum(thisCluster.logL(kkk,:,PRIMARY));
        end
        logL = thisCluster.logL_base(kkk);   %%%% logL_base does not depend on the inference parameters
        
        for contactType=INFECTED:UNINFECTED
            if (~isempty(thisCluster.contactList{contactType}))
                logL = logL+sum(thisCluster.logL(kkk,:,contactType));
            end
        end
        thisCluster.likelihoodConditional(kkk) = exp(logL);
    end
    thisCluster.logLikelihood = loge(thisCluster.likelihoodConditional*thisCluster.primaryInfectionTimeProb);
    data.cluster(clusterID) = thisCluster;
    logL_total(clusterIndex) = thisCluster.logLikelihood;
end

data.prevPara = para;
funval = sum(logL_total);
funval = funval+logL_SI;

if (isnan(funval) || ~isreal(funval))
    disp('error');
    pause
end
