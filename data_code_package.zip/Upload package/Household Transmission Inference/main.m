%%%%%%%% This code reads the household data from the xlsx flies and
%%%%%%%% then runs the inference
%%%%%%%% The output is the posterior distribution of the parameters which
%%%%%%%% corresponds to the variable "chain.record"

clear all;
close all;

rand('state', 1e5);
randn('state', 1e5);

epiGrowthRate = log(2)/5.2;
data.dt = 0.1;
mean_Incub = 5.5;
median_Incub = 5.1;
data.mu_Incub = log(median_Incub);
data.sigma_Incub = sqrt(2*(log(mean_Incub)-data.mu_Incub));
data.prevPara = [];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
loadSerialIntervalData
% Household clusters
clusterTimeSpan = [];

[numData, textData] = xlsread('shenzhen_pair_200527.xlsx');
textDataOriginal = textData;
textData(1,:) = [];
[numData_anhui, textData_anhui] = xlsread('anhui_pair_200527.xlsx');
numData_anhui(:,2) = numData_anhui(:,2)+20000;
textData_anhui(1,:) = [];
textData = [textData(:,1:19); textData_anhui];
numData = [numData; numData_anhui];

clusterList = unique(numData(:,2));
numClusters = numel(clusterList);
maxIncubationTime = -1;

INFECTED = 1;
UNINFECTED = 2;

MALE = 1;
FEMALE = 2;

PRIMARY_ID = 1;
CLUSTER_ID = 2;
PRIMARY_AGE = 3;
PRIMARY_GENDER = 4;
PRIMARY_INFECTION_DATE_LB = 5;
PRIMARY_INFECTION_DATE_UB = 6;
PRIMARY_ONSET_DATE = 8;
PRIMARY_QUARANTINE_DATE = 9;

CONTACT_ID = 12;
CONTACT_AGE = 13;
CONTACT_GENDER = 14;
CONTACT_DATE_LB = 15;
CONTACT_DATE_UB = 16;
INFECTED_ONSET_DATE = 17;
INFECTED_QUARANTINE_DATE = 18;
CONTACT_INFECTION_STATUS = 19;


%%%%%%%%%%% Control panel  %%%%%%%%%%%%%%%%%%%%%%%
data.jointInference = false;
data.dir = 'Results/';
data.ageInfectiousnessType = 1;
data.infectiousnessType = 1;
data.maxClusterSize = 8;
data.interpolationMethod = 'pchip';
data.fullCalc = true;
data.gammaGT = true;

%%%% The nested loops are used to sweep through different scenarios:
%%%% 1) including/excluding clusters with co-primary cases
%%%% 2) using different age knots when inferring age-specific susceptibility and infectiousness
%%%% 3) using gamma or lognormal generation time distribution

for singlePrimaryCase=0:1
    for susType = 3:4
        data.singlePrimaryCase = singlePrimaryCase;
        data.ageSusceptibilityType = susType;
        if (~isfolder(data.dir))
            mkdir(data.dir);
        end
        filename = [data.dir 'results_s' num2str(data.singlePrimaryCase) '_susType' num2str(data.ageSusceptibilityType) '_gam' num2str(data.gammaGT) '.mat'];
        
        if (exist(filename, 'file'))
            continue;
        else
            disp(filename);
            save(filename);
        end
        data.filename = filename;
        
        data.numBeta = min(data.maxClusterSize,8)-1;
        data.clusterList = clusterList;
        if (data.ageSusceptibilityType==1)
            data.ageSuscepPartition = [0 10 30 100];
            % data.susceptibility = [p1 p1 1 1];
            startingTheta = 0.5;
        elseif (data.ageSusceptibilityType==2)
            data.ageSuscepPartition = [0 15 30 100];
            % data.susceptibility = [p1 p1 1 1];
            startingTheta = 0.5;
        elseif (data.ageSusceptibilityType==3)
            data.ageSuscepPartition = [0 10 30 100];
            % data.susceptibility = [p1 p2 1 1];
            startingTheta = [0.5 0.5]';
        elseif (data.ageSusceptibilityType==4)
            data.ageSuscepPartition = [0 15 30 100];
            % data.susceptibility = [p1 p2 1 1];
            startingTheta = [0.5 0.5]';
        end
        if (data.ageInfectiousnessType==1)
            data.ageInfectPartition = [0 45 100];
            startingTheta = [startingTheta; 1];
        elseif (data.ageInfectiousnessType==2)
            data.ageInfectPartition = [0 100];
        end
        startingTheta = [
            startingTheta
            1
            1
            0.1*ones(data.maxClusterSize-1,1)
            2
            0.1
            0.5
            1
            1
            ]';
        %%%%%%%%%%%%%%%%%%%%% Start reading household cluster data %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        clusterSize = [];
        spaceList = [];
        for ii=1:numel(data.clusterList)
            clusterID = data.clusterList(ii);
            fI = find(numData(:,CLUSTER_ID)==clusterID);
            
            %%%%%% initialize the cluster
            thisCluster.ID = clusterID;
            thisCluster.memberList = [];
            thisCluster.primaryList = [];
            thisCluster.contactList{INFECTED} = [];
            thisCluster.contactList{UNINFECTED} = [];
            thisCluster.primary = [];
            thisCluster.contact = [];
            thisCluster.FOI = [];
            thisCluster.beta = [];
            thisCluster.likelihoodConditional = [];
            thisCluster.logLikelihood = [];
            thisCluster.logL = [];
            thisCluster.logL_base = [];
            thisCluster.timeZero = 1e300;
            thisCluster.timeMax = -1e300;
            
            for jj=1:numel(fI)
                rowIndex = fI(jj);
                primaryID = numData(rowIndex,PRIMARY_ID);
                
                %%%%% read in primary cases
                if (~any(thisCluster.primaryList==primaryID))
                    thisCluster.memberList(end+1) = primaryID;
                    thisCluster.primaryList(end+1) = primaryID;
                    
                    thisPrimary = numel(thisCluster.primaryList);
                    age = numData(rowIndex, PRIMARY_AGE);
                    
                    thisCluster.primary(thisPrimary).ID = primaryID;
                    thisCluster.primary(thisPrimary).age = age;
                    thisCluster.primary(thisPrimary).genderText = textData(rowIndex, PRIMARY_GENDER);
                    if (strcmp(thisCluster.primary(thisPrimary).genderText, 'M'))
                        thisCluster.primary(thisPrimary).gender = MALE;
                    else
                        thisCluster.primary(thisPrimary).gender = FEMALE;
                    end
                    
                    infectionDate_LB = datenum(textData(rowIndex, PRIMARY_INFECTION_DATE_LB));
                    infectionDate_UB = datenum(textData(rowIndex, PRIMARY_INFECTION_DATE_UB));
                    
                    thisCluster.primary(thisPrimary).infectionDateText = textData(rowIndex,PRIMARY_INFECTION_DATE_LB:PRIMARY_INFECTION_DATE_UB);
                    thisCluster.primary(thisPrimary).infectionDate = [infectionDate_LB infectionDate_UB];
                    
                    thisCluster.primary(thisPrimary).onsetDateText = textData(rowIndex,PRIMARY_ONSET_DATE);
                    if (strcmp('',thisCluster.primary(thisPrimary).onsetDateText))
                        thisCluster.primary(thisPrimary).onsetDate = -1;
                    else
                        thisCluster.primary(thisPrimary).onsetDate = datenum(textData(rowIndex,PRIMARY_ONSET_DATE))+0.5;
                    end
                    if ( thisCluster.primary(thisPrimary).onsetDate> 0 && infectionDate_LB> thisCluster.primary(thisPrimary).onsetDate)
                        disp(['Error in cluster ' num2str(clusterID) ' primary ' num2str(primaryID) ': onset date earlier than exposure date']);
                    end
                    thisCluster.primary(thisPrimary).quarantineDateText = textData(rowIndex,PRIMARY_QUARANTINE_DATE);
                    
                    if (strcmp('',thisCluster.primary(thisPrimary).quarantineDateText))
                        thisCluster.primary(thisPrimary).quarantineDate = -1;
                    else
                        thisCluster.primary(thisPrimary).quarantineDate = datenum(thisCluster.primary(thisPrimary).quarantineDateText)+0.5;
                    end
                    if (thisCluster.primary(thisPrimary).onsetDate>-1)
                        thisCluster.primary(thisPrimary).infectionDate = min(thisCluster.primary(thisPrimary).infectionDate, thisCluster.primary(thisPrimary).onsetDate);
                    elseif (thisCluster.primary(thisPrimary).quarantineDate>-1)
                        thisCluster.primary(thisPrimary).infectionDate = min(thisCluster.primary(thisPrimary).infectionDate, thisCluster.primary(thisPrimary).quarantineDate);
                    end
                    thisCluster.primary(thisPrimary).infectionDate = floor(thisCluster.primary(thisPrimary).infectionDate);
                    
                end
                thisPrimary = find(thisCluster.primaryList==primaryID);
                
                %%%% read in contacts
                contactID = numData(rowIndex,CONTACT_ID);
                age = numData(rowIndex,CONTACT_AGE);
                
                genderText = textData(rowIndex,CONTACT_GENDER);
                if (strcmp(genderText, 'M'))
                    gender = MALE;
                else
                    gender = FEMALE;
                end
                contactInfectionStatus = textData(rowIndex,CONTACT_INFECTION_STATUS);
                
                startDateText = textData(rowIndex,CONTACT_DATE_LB);
                endDateText = textData(rowIndex,CONTACT_DATE_UB);
                
                if (strcmp(contactInfectionStatus, 'Y'))
                    contactType = INFECTED;
                else
                    contactType = UNINFECTED;
                end
                
                if (~any(thisCluster.memberList==contactID))
                    thisCluster.memberList(end+1) = contactID;
                    thisCluster.contactList{contactType}(end+1) = contactID;
                    
                    thisContact = numel(thisCluster.contactList{contactType});
                    
                    thisCluster.contact{contactType}(thisContact).ID = contactID;
                    thisCluster.contact{contactType}(thisContact).age = age;
                    %                 thisCluster.contact{contactType}(thisContact).ageGroup = ageGroup;
                    thisCluster.contact{contactType}(thisContact).genderText = genderText;
                    thisCluster.contact{contactType}(thisContact).gender = gender;
                    thisCluster.contact{contactType}(thisContact).contactDatesText = [];
                    thisCluster.contact{contactType}(thisContact).contactDates = [];
                    thisCluster.contact{contactType}(thisContact).quarantineDatesText = [];
                    thisCluster.contact{contactType}(thisContact).quarantineDates = [];
                    
                    if (contactType==INFECTED)
                        thisCluster.contact{contactType}(thisContact).onsetDateText = textData(rowIndex,INFECTED_ONSET_DATE);
                        if (strcmp('',thisCluster.contact{contactType}(thisContact).onsetDateText))
                            thisCluster.contact{contactType}(thisContact).onsetDate = -1;
                        else
                            thisCluster.contact{contactType}(thisContact).onsetDate = datenum(textData(rowIndex,INFECTED_ONSET_DATE))+0.5;
                        end
                        thisCluster.contact{contactType}(thisContact).quarantineDateText = textData(rowIndex,INFECTED_QUARANTINE_DATE);
                        if (strcmp('',thisCluster.contact{contactType}(thisContact).quarantineDateText))
                            thisCluster.contact{contactType}(thisContact).quarantineDate = -1;
                        else
                            thisCluster.contact{contactType}(thisContact).quarantineDate = datenum(textData(rowIndex,INFECTED_QUARANTINE_DATE))+0.5;
                        end
                        
                    end
                end
                thisCluster.contact{contactType}(thisContact).contactDatesText{thisPrimary} = textData(rowIndex,CONTACT_DATE_LB:CONTACT_DATE_UB);
                startDate = datenum(startDateText);
                endDate = datenum(endDateText);
                clusterTimeSpan(end+1) = endDate-startDate;
                if (startDate>endDate)
                    disp('error');
                    
                end
                startDate = max(startDate, thisCluster.primary(thisPrimary).infectionDate(1));
                thisCluster.contact{contactType}(thisContact).contactDates(thisPrimary,:) = [startDate endDate];
            end
            
            %%%%%%%%% define time zero: the earliest possible time
            %%%%%%%%% of infection among all primary cases
            for jj=1:numel(thisCluster.primaryList)
                if (thisCluster.primary(jj).infectionDate(1)<thisCluster.timeZero)
                    thisCluster.timeZero = thisCluster.primary(jj).infectionDate(1);
                    thisCluster.timeZeroText = thisCluster.primary(jj).infectionDateText(1);
                end
            end
            thisCluster.timerZero = thisCluster.timeZero-7;  % to accomodate potential large values of infStartTime
            
            %     [aa_Incub, bb_Incub] = gampara(mean_Incub, std_Incub);
            for jj=1:numel(thisCluster.primaryList)
                thisCluster.primary(jj).infectionDate = thisCluster.primary(jj).infectionDate-thisCluster.timeZero;
                thisCluster.primary(jj).onsetDate = thisCluster.primary(jj).onsetDate-thisCluster.timeZero;
                thisCluster.primary(jj).quarantineDate = thisCluster.primary(jj).quarantineDate-thisCluster.timeZero;
                
                thisCluster.primary(jj).infectionTime = thisCluster.primary(jj).infectionDate(1):thisCluster.primary(jj).infectionDate(end);
                thisCluster.timeLockdown = datenum('01/24/2020')-thisCluster.timeZero+1;
                if (thisCluster.timeLockdown< thisCluster.primary(jj).infectionTime(1))
                    exp_tv = ones(1,numel(thisCluster.primary(jj).infectionTime));
                else
                    exp_tv = exp(epiGrowthRate*thisCluster.primary(jj).infectionTime);
                    if (thisCluster.timeLockdown<=thisCluster.primary(jj).infectionTime(end))
                        exp_tv((thisCluster.timeLockdown+1):end) = 0;
                    end
                end
                thisCluster.primary(jj).infectionTimeProb = exp_tv/sum(exp_tv);
                if (thisCluster.primary(jj).onsetDate>0)
                    %             thisCluster.primary(jj).incubationPMF = gampdf(thisCluster.primary(jj).onsetDate-thisCluster.primary(jj).infectionTime, aa_Incub, bb_Incub);
                    thisCluster.primary(jj).incubationPMF = lognpdf(thisCluster.primary(jj).onsetDate-thisCluster.primary(jj).infectionTime, data.mu_Incub, data.sigma_Incub);
                else
                    thisCluster.primary(jj).incubationPMF = ones(1,numel(thisCluster.primary(jj).infectionTime));
                end
                if (thisCluster.primary(jj).quarantineDate>0)
                    %             thisCluster.primary(jj).incubationCensoredProb = gamcdf(thisCluster.primary(jj).quarantineDate-thisCluster.primary(jj).infectionTime, aa_Incub, bb_Incub);
                    thisCluster.primary(jj).incubationCensoredProb = logncdf(thisCluster.primary(jj).quarantineDate-thisCluster.primary(jj).infectionTime, data.mu_Incub, data.sigma_Incub);
                else
                    thisCluster.primary(jj).incubationCensoredProb = ones(1,numel(thisCluster.primary(jj).infectionTime));
                end
                if (thisCluster.primary(jj).onsetDate>0)
                    relativeProb = thisCluster.primary(jj).infectionTimeProb.*thisCluster.primary(jj).incubationPMF;
                else
                    relativeProb = thisCluster.primary(jj).infectionTimeProb.*thisCluster.primary(jj).incubationCensoredProb;
                end
                relativeProb = relativeProb/sum(relativeProb);
                relativeProb = cumsum(relativeProb);
                fI_2 = find(relativeProb>0.01);
                thisCluster.primary(jj).infectionTime = thisCluster.primary(jj).infectionTime(fI_2);
                thisCluster.primary(jj).infectionTimeProb = thisCluster.primary(jj).infectionTimeProb(fI_2)/sum(thisCluster.primary(jj).infectionTimeProb(fI_2));
                thisCluster.primary(jj).incubationPMF = thisCluster.primary(jj).incubationPMF(fI_2)/sum(thisCluster.primary(jj).incubationPMF(fI_2));
                thisCluster.primary(jj).incubationTime = thisCluster.primary(jj).onsetDate-thisCluster.primary(jj).infectionTime;
            end
            
            for contactType=INFECTED:UNINFECTED
                for jj=1:numel(thisCluster.contactList{contactType})
                    thisCluster.contact{contactType}(jj).contactDates = thisCluster.contact{contactType}(jj).contactDates-thisCluster.timeZero;
                    if (contactType==INFECTED)
                        thisCluster.contact{contactType}(jj).onsetDate = thisCluster.contact{contactType}(jj).onsetDate-thisCluster.timeZero;
                        tv = thisCluster.contact{contactType}(jj).onsetDate:-data.dt:0;
                        
                        xx = logncdf(tv, data.mu_Incub, data.sigma_Incub);
                        xx = xx(2:end)-xx(1:end-1);
                        thisCluster.contact{contactType}(jj).incubationPMF = xx/sum(xx);
                        
                        thisCluster.contact{contactType}(jj).quarantineDate = thisCluster.contact{contactType}(jj).quarantineDate-thisCluster.timeZero;
                    end
                    
                    thisCluster.timeMax = max(thisCluster.timeMax, thisCluster.contact{contactType}(jj).contactDates(end));
                end
            end
            
            clusterSize(end+1) = numel(thisCluster.memberList);
            commandText = '(';
            commandTextProb = '(';
            commandTextIncub = '(';
            commandTextIncubPMF = '(';
            for jj=1:numel(thisCluster.primaryList)
                commandText = [commandText 'thisCluster.primary(' num2str(jj) ').infectionTime'];
                commandTextProb = [commandTextProb 'thisCluster.primary(' num2str(jj) ').infectionTimeProb'];
                commandTextIncub = [commandTextIncub 'thisCluster.primary(' num2str(jj) ').incubationTime'];
                commandTextIncubPMF = [commandTextIncubPMF 'loge(thisCluster.primary(' num2str(jj) ').incubationPMF)'];
                if (jj==numel(thisCluster.primaryList))
                    commandText = [commandText ');'];
                    commandTextProb = [commandTextProb ');'];
                    commandTextIncub = [commandTextIncub ');'];
                    commandTextIncubPMF = [commandTextIncubPMF ');'];
                else
                    commandText = [commandText ','];
                    commandTextProb = [commandTextProb ','];
                    commandTextIncub = [commandTextIncub ','];
                    commandTextIncubPMF = [commandTextIncubPMF ','];
                end
            end
            
            commandText = ['thisCluster.primaryInfectionTime = allcomb' commandText];
            commandTextProb = ['thisCluster.primaryInfectionTimeProb = allcomb' commandTextProb];
            commandTextIncub = ['thisCluster.primaryIncubation = allcomb' commandTextIncub];
            commandTextIncubPMF = ['thisCluster.primaryIncubationPMF_log = allcomb' commandTextIncubPMF];
            
            eval(commandText);
            eval(commandTextProb);
            eval(commandTextIncub);
            eval(commandTextIncubPMF);
            thisCluster.primaryInfectionTimeProb = prod(thisCluster.primaryInfectionTimeProb,2);
            
            thisCluster.attackRate = numel(thisCluster.contactList{INFECTED})/(numel(thisCluster.contactList{INFECTED})+numel(thisCluster.contactList{UNINFECTED}));
            
            thisCluster.size = numel(thisCluster.memberList);
            data.cluster(clusterID) = thisCluster;
            
            spaceList(end+1) = numel(thisCluster.primaryInfectionTimeProb);
            attackRate(ii,:) = [numel(thisCluster.primaryList) numel(thisCluster.contactList{INFECTED}) numel(thisCluster.contactList{UNINFECTED})];
            
            maxIncubationTime = max(maxIncubationTime, max(thisCluster.primaryIncubation(:)));
        end
        
        
        %%%%%%%%%%%%%%%%%%% Start running the inference %%%%%%%%%%%%%%%%%%
        data.maxIncubationTime = maxIncubationTime;
        
        data.prevPara = [];
        data.numPara = numel(startingTheta);
        
        chainOptions.data = data;
        chainOptions.numStepsPerParameter = 100000;
        chainOptions.minNumStepsBeforeRestart = 200;
        chainOptions.numStepsBetweenDisplay = 100;
        chainOptions.probAcceptTargetRange = [0.2 0.6];
        chainOptions.startingPoint = startingTheta;
        
        chainOptions.LB = zeros(1, numel(chainOptions.startingPoint));
        chainOptions.UB = 1000*ones(1, numel(chainOptions.startingPoint));
        
        numParameters = size(chainOptions.startingPoint,2);
        chainOptions.stepSTD = 0.1*ones(1, numParameters);
        chainOptions.logSpace = zeros(1, numParameters);
        
        chain = MCMC(@logLikelihood, @(x) 0, chainOptions);
        
    end
end