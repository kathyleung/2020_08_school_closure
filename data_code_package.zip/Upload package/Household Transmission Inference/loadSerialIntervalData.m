data.SI = [
    5	5
    9	9
    7	7
    7	7
    3	3
    7	7
    4	7
    5	6
    6	6
    3	6
    3	3
    3	3
    4	4
    6	6
    9	9
    9	9
    8	8
    6	14
    3	3
    0	3
    0	1
    4	5
    0	1
    3	4
    2	2
%     -3	3
%     -5	1
%     -6	1
%     3	6
%     -6	1
%     -3	3
%     -4	2
    2	2
    9	9
    7	7
    7	7
    7	7
    6	6
    7	7
    4	4
    2	2
    5	5
    5	5
    5	5
    3	3
    3	3
    1	1
    6	6
    7	7
    8	8
    3	3
    4	4
    4	4
    2	2
    2	2
    4	4
    1	1
    7	7
    5	5
    2	2
    7	7
    10	10
    2	2
    2	2
    2	2
    11	11
    4	4
    3	3
    4	4
    2	2
    3	3
    4	4
    1	1
    9	9
    ];

fI = find(data.SI(:,1)==data.SI(:,2));
data.serialInterval_exact = data.SI(fI,1);
fI = find(data.SI(:,1)~=data.SI(:,2));
data.serialInterval_range = data.SI(fI,:);