function chain = MCMC(logLikelihood, logPrior, chainOptions)

chain.data = chainOptions.data;

chain.LB = chainOptions.LB;
chain.UB = chainOptions.UB;
chain.numParameters = numel(chain.LB);
chain.minProbAccept = chainOptions.probAcceptTargetRange(1);
chain.maxProbAccept = chainOptions.probAcceptTargetRange(2);
chain.numStepsPerParameter = chainOptions.numStepsPerParameter;
chain.startingPoint = chainOptions.startingPoint;
if (~isempty(chainOptions.stepSTD))
    chain.stepSTD = chainOptions.stepSTD;
else
    chain.stepSTD = repmat(0.1, 1, chain.numParameters);
end
if (size(chain.stepSTD,1)>1)
    chain.stepSTD = chain.stepSTD';
end
chain.logSpace = chainOptions.logSpace;
chain.dir = chain.data.dir;

chain.numParameters = numel(chain.LB);
dirName = chain.dir;
if (~isdir(dirName))
    mkdir(dirName);
end
[rsize, csize] = size(chain.startingPoint);
if (rsize~=1 && csize==1)
    chain.startingPoint = chain.startingPoint';
end

minNumStepsBeforeRestart = chainOptions.minNumStepsBeforeRestart;
numStepsBetweenDisplay = chainOptions.numStepsBetweenDisplay;
numStepsBetweenBackup = chain.numStepsPerParameter/5;

rvStorageSize = min(chain.numStepsPerParameter,1000)*chain.numParameters;
chain.probAccept = (chain.minProbAccept+chain.maxProbAccept)/2*ones(1, chain.numParameters);
oldProbAccept = -1*ones(1, chain.numParameters);


mm = chain.numStepsPerParameter*chain.numParameters;
chain.record = zeros(mm, chain.numParameters);
chain.logLikelihood = zeros(mm, 1);
chain.logPosterior = zeros(mm, 1);

chainGood = false;

chain.bestParameters = chain.startingPoint;
chain.bestLogLikelihood = -1e300;
chain.bestLogPosterior = -1e300;

chainNum = 1;
bbb = -1;
pstar = (chain.minProbAccept+chain.maxProbAccept)/2;
pstar_logit = log(pstar/(1-pstar));
while (chainGood==false)
    x = chain.bestParameters;
    [xLogLikelihood, prev_data] = logLikelihood(x, chain.data);
    chain.data = prev_data;
    xLogPosterior = xLogLikelihood+logPrior(x);
    
    chain.record(1,:) = x;
    chain.logLikelihood(1) = xLogLikelihood;
    chain.logPosterior(1) = xLogPosterior;
    numAccept = ones(1, chain.numParameters);
    numSteps = ones(1, chain.numParameters);
    
    for para=1:chain.numParameters
        if (chain.probAccept(para)<chain.minProbAccept || chain.probAccept(para)>chain.maxProbAccept)
            eps2 = 1e-10;
            p = max(min(chain.probAccept(para), 1-eps2), eps2);
            p_logit = log(p/(1-p));
            
            scalingFactor = min(10, max(0.1, exp((pstar_logit-p_logit)/bbb)));
            chain.stepSTD(para) = chain.stepSTD(para)*scalingFactor;
        end
        
    end
    
    paraUpdate = 1;
    tic;
    totalSecElapsed = 0;
    
    probStorage = unifrnd(0, 1, rvStorageSize, 1);
    probStorageIndex = 1;
    
    stepStorage = normrnd(0, 1, rvStorageSize, 1);
    stepStorageIndex = 1;
    for iter=2:(chain.numStepsPerParameter*chain.numParameters)
        chain.iter = iter;
        % next step in the random walk
        y = x;
        
        %%%%% Neeed to modify the stepping of storage
        if (chain.logSpace(paraUpdate)==false)
            y(paraUpdate) = x(paraUpdate)+stepStorage(stepStorageIndex)*chain.stepSTD(paraUpdate);
        else
            y(paraUpdate) = x(paraUpdate)*exp(stepStorage(stepStorageIndex)*chain.stepSTD(paraUpdate));
        end
        
        stepStorageIndex = stepStorageIndex+1;
        if (stepStorageIndex+chain.numParameters>rvStorageSize)
            stepStorage = normrnd(0, 1, rvStorageSize*chain.numParameters, 1);
            stepStorageIndex = 1;
        end
        
        while (y(paraUpdate)<chain.LB(paraUpdate) || y(paraUpdate)>chain.UB(paraUpdate))
            if (y(paraUpdate)<chain.LB(paraUpdate))
                y(paraUpdate) = chain.LB(paraUpdate)+(chain.LB(paraUpdate)-y(paraUpdate));
            else
                y(paraUpdate) = chain.UB(paraUpdate)-(y(paraUpdate)-chain.UB(paraUpdate));
            end
        end
        
        [yLogLikelihood, prev_data] = logLikelihood(y, chain.data);
        
        
        yLogPosterior = yLogLikelihood+logPrior(y);
        
        if (yLogLikelihood>-1e300 && probStorage(probStorageIndex)<min(1,exp(yLogPosterior-xLogPosterior)))
            x = y;
            xLogLikelihood = yLogLikelihood;
            xLogPosterior = yLogPosterior;
            numAccept(paraUpdate) = numAccept(paraUpdate)+1;
            chain.data = prev_data;
        end
        
        probStorageIndex = probStorageIndex+1;
        if (probStorageIndex==rvStorageSize)
            probStorage = unifrnd(0, 1, rvStorageSize, 1);
            probStorageIndex = 1;
        end
        
        if (xLogLikelihood>chain.bestLogLikelihood)
            chain.bestLogLikelihood = xLogLikelihood;
        end
        if (xLogPosterior>chain.bestLogPosterior)
            chain.bestLogPosterior =  xLogPosterior;
            chain.bestParameters = x;
        end
        
        numSteps(paraUpdate) = numSteps(paraUpdate)+1;
        
        chain.record(iter,:) = x;
        chain.logLikelihood(iter) = xLogLikelihood;
        chain.logPosterior(iter) = xLogPosterior;
        chain.probAccept(paraUpdate) = numAccept(paraUpdate)/numSteps(paraUpdate);
        
        if ((chain.probAccept(paraUpdate)>=chain.minProbAccept && chain.probAccept(paraUpdate)<=chain.maxProbAccept))
            chainGood = true;
        else
            chainGood = false;
            
            if (iter>chain.numParameters*minNumStepsBeforeRestart)
                disp('');
                disp(['Restarting MCMC after ' num2str(numSteps(paraUpdate)-1)  ' steps because the following P(Accept) is out of range. ']);
                disp(sprintf('Parameters\t\tP(Accept)\t\tchain.stepSTD'));
                fI = find(chain.probAccept < chain.minProbAccept | chain.probAccept > chain.maxProbAccept);
                AA = [fI; chain.probAccept(fI); chain.stepSTD(fI)];
                disp(sprintf('%5d\t\t\t%5.2f\t\t\t%8.3e\n', AA));
                disp('');
                stepSTD_record(chainNum,:) = chain.stepSTD;
                probAccept_record(chainNum, :) = chain.probAccept;
                
                if (chainNum>1)
                    figure(434);
                    clf;
                    totalNumPlots = chain.numParameters;
                    numFigCol = min(5, totalNumPlots);
                    numFigRow = ceil(totalNumPlots/numFigCol);
                    for ii=1:chain.numParameters
                        subplot(numFigRow, numFigCol, ii);
                        hold on;
                        X_regress = [ones(chainNum, 1) log(stepSTD_record(:,ii))];
                        Y_regress = log(probAccept_record(:,ii)./(1-max(1e-10,probAccept_record(:,ii))));
                        [B, ~] = regress(Y_regress, X_regress);
                        plot(log(stepSTD_record(:,ii)), Y_regress, 'o');
                        plot(log(stepSTD_record(:,ii)), X_regress*B);
                        title(['Slope = ' num2str(B(2))]);
                    end
                end
                
                plotMCMC(chain, false);
                chainNum = chainNum+1;
                break;
            end
        end
        
        if (paraUpdate==chain.numParameters)
            paraUpdate = 1;
        else
            paraUpdate = paraUpdate+1;
        end
        
        totalSecElapsed = totalSecElapsed+toc;
        tic;
        if (paraUpdate==1 && mod(numSteps(paraUpdate), numStepsBetweenDisplay)==0)
            if (~isempty(chain.dir))
                disp(chain.dir);
            end
            [zLogLikelihood, prev_data] = logLikelihood(chain.bestParameters, chain.data);
            chain.data = prev_data;
            tt = ['MCMC ' num2str(numSteps(paraUpdate)/chain.numStepsPerParameter*100, '%.2f') '% complete. Time elapsed = ' ...
                num2str(totalSecElapsed/60, '%.1f') ' min. Remaining time = ' ...
                num2str(totalSecElapsed/numSteps(paraUpdate)*(chain.numStepsPerParameter-numSteps(paraUpdate))/60, '%.1f') ' min.'];
            disp(tt);
            disp(['Best log-likelihood: ' num2str(chain.bestLogLikelihood)]);
            disp(['Best log-posterior: ' num2str(chain.bestLogPosterior)]);
            plotMCMC(chain, false);
            save(chain.data.filename);
        end
        %         if (paraUpdate==1 && mod(numSteps(paraUpdate), numStepsBetweenBackup)==0)
        % %             fname = [chain.dir '/MCMC_Records'];
        % %             save(fname, 'chain');
        %             plotMCMC(chain, false);
        %         end
    end
end
plotMCMC(chain, false);
end

function funval = plotMCMC(chain, runAutocorrelation)

chain.numParameters = size(chain.record,2);
if (runAutocorrelation)
    lagmax = min(size(chain.record,1)-5,1000);
    for para=1:chain.numParameters
        for lag=1:lagmax
            x1 = chain.record(1:(end-lag), para);
            x2 = chain.record((1+lag):end, para);
            RR = corrcoef(x1, x2);
            autoCorr(para, lag) = RR(1,2);
        end
    end
end

h = figure(100);
set(h, 'Name', 'Traceplots');
clf;
numFigCol = 3;
numFigRow = ceil(chain.numParameters/numFigCol);
nn = chain.iter-1;
subplotIndex = 0;
for ii=1:chain.numParameters
    subplotIndex = subplotIndex+1;
    subplot(numFigRow, numFigCol, subplotIndex);
    plot(chain.record(1:nn,ii));
    xlim([0 nn]);
    ylabel(['Para ' num2str(ii)]);
end

h = figure(101);
set(h, 'Name', 'Posterior distributions');
clf;
numFigCol = 3;
numFigRow = ceil(chain.numParameters/numFigCol);
nn = chain.iter-1;
subplotIndex = 0;
for ii=1:chain.numParameters
    subplotIndex = subplotIndex+1;
    subplot(numFigRow, numFigCol, subplotIndex);
    hist(chain.record(1:nn,ii), round(sqrt(nn))/2);
    xlabel(['Para ' num2str(ii)]);
end

h = figure(103);
set(h, 'Name', 'Other stats');
numFigRow = 1;
numFigCol = 3;
subplotIndex = 0;
subplotIndex = subplotIndex+1;
subplot(numFigRow, numFigCol, subplotIndex)
plot(chain.logLikelihood(1:nn));
xlim([0 nn]);
ylabel('logL');

subplotIndex = subplotIndex+1;
subplot(numFigRow, numFigCol, subplotIndex)
bar(chain.probAccept);
xlim([0 chain.numParameters+1])
ylim([0 1]);
ylabel('P(Accept)');
xlabel('Parameter');

end