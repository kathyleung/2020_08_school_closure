function funval = loge(x)

minProb = 1e-300;
funval = log(x+minProb);