function [contactMatrix, ageDist] = makeContactMatrix(agePartition, M, P)

warning off;

%%%%%%%%%%%% main control
numAgeGroups = numel(agePartition(:,1));

ageBins = [0:74 100];

numContactMatrix = [];
popSize = [];
[rsize, csize] = size(M);

for i=1:csize
    if (i<csize)
        numContactMatrix = [numContactMatrix repmat(M(:,i), 1, 5)];
        popSize = [popSize; repmat(P(i)/5, 5, 1)];
    else
        numContactMatrix = [numContactMatrix M(:,i)];
        popSize = [popSize; P(i)];
    end
end

M = numContactMatrix;
numContactMatrix = [];
[rsize, csize] = size(M);
for i=1:rsize
    if (i<rsize)
        numContactMatrix = [numContactMatrix; repmat(M(i,:)/5, 5, 1)];
    else
        numContactMatrix = [numContactMatrix; M(i,:)];
    end
end

%%%%%%%%%%%%%%%% Construct contact matrix with customized age partition
numer = zeros(numAgeGroups, numAgeGroups);
denom = zeros(numAgeGroups, numAgeGroups);

for a=1:numAgeGroups  % a is the contact
    for b=1:numAgeGroups  % b is the subject
        fa = find(ageBins>=agePartition(a,1) & ageBins<=agePartition(a,2));
        fb = find(ageBins>=agePartition(b,1) & ageBins<=agePartition(b,2));
        for i=1:numel(fa)
            for j=1:numel(fb)
                numer(a,b) = numer(a,b)+numContactMatrix(fa(i), fb(j))*popSize(fb(j));
            end
        end
        denom(:,b) = sum(popSize(fb));
    end
end
M = numer./denom;   % M(a,b) is the average number of age group a contact per person in age group b (columns)
for a=1:numAgeGroups
    fa = find(ageBins>=agePartition(a,1) & ageBins<=agePartition(a,2));
    C(a,:) = M(a,:)/sum(popSize(fa));
    ageDist(a) = sum(popSize(fa));
end

% C(a,b) is the probability that a person from age group is a contact of a person in age group b (columns)

contactMatrix = M;
% contactMatrix = (C'+C)/2;   %following galvani's method
% ageDist = ageDist/sum(ageDist);



