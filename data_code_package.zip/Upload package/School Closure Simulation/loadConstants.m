
NONE = 1; 
ALL = 2;
PRIMARY = 3;
SECONDARY = 4;

policyLabel = {'None', 'All', 'Primary', 'Secondary'};