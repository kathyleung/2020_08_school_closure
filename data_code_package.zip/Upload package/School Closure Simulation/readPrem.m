clear all;
close all;

filename = 'PopulationCountry.xlsx';
P = importdata(filename);
P.textdata(1,:) = [];
countryNames = P.textdata(1:end,2);
countryPopSize = P.data(:,3+(1:21));
countryPopSize(:,16) = sum(countryPopSize(:,16:end),2);
countryPopSize(:,17:end) = [];
countryOutOfSchoolRate = P.data(:,27:28);
% countryIncomeGroup = P.data(:,end);
countryGDPpc = P.data(:,25);
for ii=1:numel(countryNames)
    if (strcmp(P.textdata(ii,end),'H'))
        countryIncomeGroup(ii) = 1;
    elseif (strcmp(P.textdata(ii,end),'UM'))
        countryIncomeGroup(ii) = 2;
    elseif (strcmp(P.textdata(ii,end),'LM'))
        countryIncomeGroup(ii) = 3;
    elseif (strcmp(P.textdata(ii,end),'L'))
        countryIncomeGroup(ii) = 4;
    end
end

for jj=1:2
    xx = countryOutOfSchoolRate(:,jj);
    for ii=1:4
        fI = find(countryIncomeGroup==ii);
        yy = xx(fI);
        meanOutOfSchoolRate(ii,jj) = mean(yy(~isnan(yy)));
        fI = find(countryIncomeGroup==ii & isnan(xx'));
        countryOutOfSchoolRate(fI,jj) = meanOutOfSchoolRate(ii,jj);
    end
end

dir = [];
missingCountry = [];
for ll=1:5
    countryIndex = 1;
    for kk=1:2
        if (ll==1)
            filename = ['MUestimates_all_locations_' num2str(kk) '.xlsx'];
        elseif (ll==2)
            filename = ['MUestimates_home_' num2str(kk) '.xlsx'];
        elseif (ll==3)
            filename = ['MUestimates_school_' num2str(kk) '.xlsx'];
        elseif (ll==4)
            filename = ['MUestimates_work_' num2str(kk) '.xlsx'];
        elseif (ll==5)
            filename = ['MUestimates_other_locations_' num2str(kk) '.xlsx'];
        end
        
        [status, sheets] = xlsfinfo(filename);
        for ii=1:numel(sheets)
            if (ll==1)
                countryFound(ii,kk) = false;
                for jj=1:size(countryNames,1)
                    if (strcmp(countryNames{jj}, sheets{ii}))
                        countryFound(ii,kk) = true;
                        break;
                    end
                end
                if (countryFound(ii,kk))
                    ageDist(countryIndex,:) = countryPopSize(jj,:);
                    country{countryIndex} = char(sheets{ii});

                    GDPpc(countryIndex) = countryGDPpc(jj);
                    outOfSchoolRate(countryIndex,:) = countryOutOfSchoolRate(jj,:);
                    incomeGroup(countryIndex) = countryIncomeGroup(jj);
                else
                    missingCountry{end+1} = sheets{ii};
                end
            end
            if (countryFound(ii,kk))
                contactMatrix(:,:,ll,countryIndex) = readmatrix(filename, 'Sheet', sheets{ii});
                countryIndex = countryIndex+1;
            end
        end
    end
end
save('prem.mat')