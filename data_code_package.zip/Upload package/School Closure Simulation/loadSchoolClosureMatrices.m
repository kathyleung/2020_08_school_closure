
for ii=1:numel(country)
    pPrimary = numSchoolchildren(ii,1)/sum(numSchoolchildren(ii,:),2);
    
    primarySchoolClosure(:,:,ii) = [
        0	0	0	0	0	0	0	0	0	0	0	0	0	0	0
        0	0	0	0	0	0	0	0	0	0	0	0	0	0	0
        0	0	1	1	1	1	1	1	1	1	1	1	1	1	1
        0	0	1	1.00	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary
        0	0	1	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary
        0	0	1	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary
        0	0	1	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary
        0	0	1	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary
        0	0	1	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary
        0	0	1	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary
        0	0	1	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary
        0	0	1	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary
        0	0	1	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary
        0	0	1	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary
        0	0	1	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary	1-pPrimary
        ];
    
    secondarySchoolClosure(:,:,ii) = [
        1	1	0	0	1	1	1	1	1	1	1	1	1	1	1
        1	1	0	0	1	1	1	1	1	1	1	1	1	1	1
        0	0	0	0	0	0	0	0	0	0	0	0	0	0	0
        0	0	0	0	0	0	0	0	0	0	0	0	0	0	0
        1	1	0	0	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary
        1	1	0	0	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary
        1	1	0	0	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary
        1	1	0	0	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary
        1	1	0	0	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary
        1	1	0	0	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary
        1	1	0	0	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary
        1	1	0	0	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary
        1	1	0	0	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary
        1	1	0	0	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary
        1	1	0	0	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary	pPrimary
        ];
end