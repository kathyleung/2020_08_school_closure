function [S, I, R, N, cumIncidence, cumOnset, growthRate, doublingTime, Rt] = transmissionModel(data)

loadConstants

numAgeGroups = data.numAgeGroups;

R0 = data.R0;
ageSusceptibility = data.ageSusceptibility;
ageInfectiousness = data.ageInfectiousness;
ageDist = data.ageDist;

dt = data.dt;
tmax = data.tmax;
tii_max = tmax/dt+1;

S = zeros(numAgeGroups, tii_max);
R = zeros(numAgeGroups, tii_max);
N = zeros(numAgeGroups, tii_max);
Rt = zeros(1,tii_max);

incidence = zeros(numAgeGroups, tii_max);
incidenceOnset = zeros(numAgeGroups, tii_max);

incubationPMF = data.incubationPMF;
generationTimePMF = data.generationTimePMF;
DI = data.meanTg;
tii_max_Tg = numel(generationTimePMF);
I = zeros(numAgeGroups, tii_max_Tg, tii_max);

startIndex_I = 1;

for kk=1:5
    numAgeGroups = size(data.contactMatrix,1);
    for ageIndex=1:numAgeGroups
        basicNGM(ageIndex,:,kk) = data.contactMatrix(ageIndex,:,kk)*ageSusceptibility(ageIndex);
    end
    for ageIndex=1:numAgeGroups
        basicNGM(:,ageIndex,kk) = basicNGM(:,ageIndex,kk)*ageInfectiousness(ageIndex);
    end
    if (kk==1)
        [eVec, eVal] = eigs(basicNGM(:,:,kk),1);
        [max_eVal, ind] = max(diag(eVal));
        seedVec = eVec(:,ind);
        seedVec = seedVec/sum(seedVec);
%         ev = ev(imag(ev)==0);
        beta0 = R0/(DI*max_eVal);
    end
    basicNGM(:,:,kk) = beta0*basicNGM(:,:,kk);
end

N(:,1) = ageDist;
I(:,:,1) =  seedVec*generationTimePMF;
S(:,1) = N(:,1)-sum(I(:,:,1),2);

for tii=1:(tii_max-1)
    I_ageSpecific = sum(I(:,:,tii),2);
    
    NGM = basicNGM(:,:,1);
    if (data.policy==ALL)
        NGM = NGM-basicNGM(:,:,3);
    elseif (data.policy==PRIMARY)
        BB = basicNGM(:,:,3).*(1-data.primarySchoolClosure);
        NGM = NGM-BB;
    elseif (data.policy==SECONDARY)
        BB = basicNGM(:,:,3).*(1-data.secondarySchoolClosure);
        NGM = NGM-BB;
    end
    
    for ageIndex=1:numAgeGroups
        NGM(ageIndex,:) = NGM(ageIndex,:)*S(ageIndex,tii)/N(ageIndex,1);
    end
    ev = eig(NGM);
    ev = ev(imag(ev)==0);
    Rt(tii) = max(ev)*DI;
    
    incidenceRate = NGM*(I_ageSpecific.*ageInfectiousness);
    dSdt = -incidenceRate;
    
    XX = incidenceRate*dt*generationTimePMF;
    if (startIndex_I==1)
        removeIndex = tii_max_Tg;
    else
        removeIndex = startIndex_I-1;
    end
    R(:,tii+1) = R(:,tii)+I(:,removeIndex,tii);
    
    tv = [startIndex_I:tii_max_Tg 1:(startIndex_I-1)];
    I(:,tv,tii+1) = I(:,tv,tii)+XX;    
    I(:,removeIndex,tii+1) = I(:,removeIndex,tii+1)-I(:,removeIndex,tii);
   
    startIndex_I = startIndex_I+1;
    if (startIndex_I>tii_max_Tg)
        startIndex_I = 1;
    end
    
    tv_max = min(tii_max, tii-1+numel(incubationPMF));
    tv = tii:tv_max;
    incidenceOnset(:,tv) = incidenceOnset(:,tv)+data.probSymp*(incidenceRate*dt)*incubationPMF(1:numel(tv));
    
    S(:,tii+1) = S(:,tii)+dSdt*dt;     
    N(:,tii+1) = S(:,tii+1)+sum(I(:,:,tii+1),2)+R(:,tii+1);
    
    incidence(:,tii+1) = incidenceRate*dt;
    if (tii*dt>50 && Rt(tii)<1 && sum(sum(I(:,:,tii)))<10)
        break;
    end
end

tii = tii-1;
S = S(:,1:1/dt:tii);
I = squeeze(sum(I(:,:,1:1/dt:tii),2));
R = R(:,1:1/dt:tii);
N = N(:,1:1/dt:tii);

Rt = Rt(1:1/dt:tii);

cumIncidence = cumsum(incidence,2);
cumIncidence = cumIncidence(:,1:1/dt:tii);

cumOnset = cumsum(incidenceOnset,2);
cumOnset = cumOnset(:,1:1/dt:tii);
incidence = incidence(:,1:1/dt:tii);
growthRate = log(sum(incidence(:,2:end))./sum(incidence(:,1:end-1)));
doublingTime = log(2)./growthRate;


