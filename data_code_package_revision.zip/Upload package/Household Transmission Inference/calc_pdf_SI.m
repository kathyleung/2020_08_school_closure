function [SI_pdf, SI_cdf] = calc_pdf_SI(SI_Vec, muInf, rhoInf, modeMeanRatio, data)

mu_Incub = data.mu_Incub;
sigma_Incub = data.sigma_Incub;
nn = 100;
nn2 = 100;
incub_max = logninv(1-1e-2, mu_Incub, sigma_Incub);
incubationVec = linspace(0, incub_max, nn);
p_inc = logncdf(incubationVec, mu_Incub, sigma_Incub);
p_inc = p_inc(2:end)-p_inc(1:end-1);
p_inc = p_inc/sum(p_inc);
incubationVec = (incubationVec(2:end)+incubationVec(1:end-1))/2;
runSuccess = false;
while (runSuccess==false)
    for jj=1:numel(SI_Vec)
        SI = SI_Vec(jj);
        
        yy = zeros(numel(incubationVec),1);
        zz = zeros(numel(incubationVec),1);
        for ii=1:numel(incubationVec)
            incTime = incubationVec(ii);
            
            UL = SI+incTime;
            if (UL<0)
                yy(ii) = 0;
            else
                startTime = muInf*incTime;
                if (UL<startTime)
                    yy(ii) = 0;
                else
                    t_eps = 0.1;
                    peakTime = max(t_eps, rhoInf*incTime);
                    
                    tv_gen = linspace(startTime, UL, nn2);
                    tv_inc = linspace(UL-startTime, 0, nn2);
                    dtv = tv_gen(2)-tv_gen(1);
                    
                    if (data.gammaGT)
                        aa_Inf = 1/(1-modeMeanRatio);
                        bb_Inf = peakTime/(aa_Inf-1);
                        f_gen = gampdf(tv_gen-startTime, aa_Inf, bb_Inf);
                    else
                        bb_Inf_sq = -2/3*log(modeMeanRatio);
                        bb_Inf = sqrt(bb_Inf_sq);
                        aa_Inf = bb_Inf_sq+log(peakTime);
                        f_gen = lognpdf(tv_gen-startTime, aa_Inf, bb_Inf);
                    end
                    f_inc = lognpdf(tv_inc, mu_Incub, sigma_Incub);
                    g_inc = logncdf(tv_inc, mu_Incub, sigma_Incub);
                    yy(ii) = (f_gen*f_inc'-f_gen([1 end])*f_inc([1 end])'/2)*dtv;
                    zz(ii) = (f_gen*g_inc'-f_gen([1 end])*g_inc([1 end])'/2)*dtv;
                end
            end
        end
        SI_pdf(jj) = p_inc*yy;
        SI_cdf(jj) = p_inc*zz;
    end
    if (any(isnan(SI_pdf)) || any(isnan(SI_cdf)))
        disp('NaN error when calculating the pdf of SI');
       pause;
    end
    if (all(SI_cdf(2:end)-SI_cdf(1:end-1)>=0))
        runSuccess = true;
    else
        nn2 = nn2*2;
        if (nn2>1e4)
            disp('Error in calculating the pdf of SI')
            pause;
        end
    end
end
    
    
