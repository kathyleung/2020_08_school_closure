clear all;
close all;

load('generationTimeCDF_Posterior.mat');
loadConstants
load('prem.mat');
numAgeGroups = size(ageDist,2);
minPopSize = 1;
totalPopSize = sum(ageDist,2);

%%%%%%%% row is the age of contact
%%%%%%%% column is the age of subject
%%%%%%%% betaMatrix is the contact probability between a person from group a and another person from group b
for jj=1:numel(country)
    for contact=1:numContactType
        for aa=1:numAgeGroups
            numContactMatrix(aa,:,contact,jj) = contactMatrix(aa,:,contact,jj).*ageDist(jj,:);
        end
        numContactMatrix(:,:,contact,jj) = (numContactMatrix(:,:,contact,jj)'+numContactMatrix(:,:,contact,jj))/2;
        for aa=1:numAgeGroups
            symContactMatrix(aa,:,contact,jj) = numContactMatrix(aa,:,contact,jj)./ageDist(jj,:);
        end
        for aa=1:numAgeGroups
            for bb=1:numAgeGroups
                betaMatrix(aa,bb,contact,jj) = symContactMatrix(aa,bb,contact,jj);
                betaMatrix_HM(aa,bb,contact,jj) = ageDist(jj,aa);
            end
        end
    end
end

data.schoolClosureEffectiveness = 0.6;
agePartition = [
    0  4
    5  12
    13 18
    19  23
    24  29
    30  34
    35  39
    40  44
    45  49
    50  54
    55  59
    60  64
    65  69
    70  74
    75  100
    ];
numAgeGroups = size(agePartition,1);
fI_65 = find(agePartition(:,1)==65):numAgeGroups;
fI_18 = 1:find(agePartition(:,2)==18);

for jj=1:numel(country)
    for contact=1:numContactType
        [betaMatrixRegroup(:,:,contact,jj), ageDistRegroup(jj,:)] = makeContactMatrix(agePartition, betaMatrix(:,:,contact,jj), ageDist(jj,:));
    end
end
betaMatrix = betaMatrixRegroup;
ageDist = ageDistRegroup;


%%%%%%%%%% Setting age-susceptibility
FLU = 1;
EQUAL = 2;
COVID = 3;
ageSuscep = ones(3, numAgeGroups);
ageSuscep(FLU,1:3) = 2;
ageSuscep(FLU,10:end) = 0.2;
load('ageSuscepPosterior.mat');

%%%%%% pathogen COVID+1 ... COVID+posterioSample correspond to the 200
%%%%%% sets of COVID parameters sampled from the posterior distrbution 
for posteriorSample=1:200
    clear xx;
    for ii=1:size(agePartition,1)
        xx(ii) = mean(ageSuscepPosterior(posteriorSample,1+(agePartition(ii,1):agePartition(ii,2))),2);
    end
    pathogen = COVID-1+posteriorSample;
    ageSuscep(pathogen,:) = xx;
end
numPathogens = pathogen;

%%%%%% Calculating contact distribution
for pathogen=1:numPathogens
    for jj=1:numel(country)
        for contact=1:numContactType
            for aa=1:numAgeGroups
                numAdjustedContactMatrix(aa,:,contact,jj,pathogen) = ...
                    ageSuscep(pathogen,aa)*(betaMatrix(aa,:,contact,jj).*ageDist(jj,:));
            end
            numAdjustedContactMatrix(:,:,contact,jj,pathogen) = (numAdjustedContactMatrix(:,:,contact,jj,pathogen)'+numAdjustedContactMatrix(:,:,contact,jj,pathogen))/2;
            for aa=1:numAgeGroups
                adjustedContactMatrix(aa,:,contact,jj,pathogen) = numAdjustedContactMatrix(aa,:,contact,jj,pathogen)./ageDist(jj,:);
            end
        end
        for contact=1:numContactType
            numAdjustedContact(:,:,contact,jj,pathogen) = triu(numAdjustedContactMatrix(:,:,contact,jj,pathogen));
        end
        for contact=1:numContactType
            AAA = numAdjustedContact(:,:,contact,jj,pathogen);
            BBB = numAdjustedContact(:,:,TOTAL,jj,pathogen);
            propAdjustedContact(jj,contact,pathogen) = sum(AAA(:))/sum(BBB(:));
        end
    end
end
numAgeGroups = size(agePartition,1);
for ii=1:numAgeGroups
    ageCDF(:,ii) = sum(ageDist(:,1:ii),2)./sum(ageDist,2);
end

ageInf = 1;
data.numAgeGroups = size(agePartition,1);
R0_Vec = [1.5 2 2.5];
counter = 1;
for R0_ii=1:numel(R0_Vec)
    data.R0 = R0_Vec(R0_ii);
    for pathogen=1:numPathogens
        eps2 = 1e-4;
        data.dt = 0.2;
        
        data.ageInfectiousness = ones(data.numAgeGroups,1);
        if (pathogen>=COVID)
            data.ageInfectiousness(1:3) = ageInf;
        end
        data.ageSusceptibility = ageSuscep(pathogen,:);
        data.probSymp = 0.5;
        data.tmax = 3600;
        data.eps = 1e-3;
        if (pathogen>=COVID)
            mean_Incub = 5.5;
            median_Incub = 5.1;
            
            tv = data.dt:data.dt:30;
            data.generationTimeCDF = interp1(generationTimeCDF_Posterior(1,:), generationTimeCDF_Posterior(2+pathogen-COVID,:),tv);
            data.generationTimeCDF = data.generationTimeCDF/max(data.generationTimeCDF);
            data.generationTimePMF = data.generationTimeCDF(2:end)-data.generationTimeCDF(1:end-1);
            data.generationTimePMF = data.generationTimePMF/sum(data.generationTimePMF);
            data.meanTg = sum(1-data.generationTimeCDF)*data.dt;
        else
            mean_Incub = 3;
            median_Incub = 2.5;
            
            numStages_I = 2;
            DI = 3;
            DI_substage = DI/numStages_I;
            [aa_Tg, bb_Tg] = gampara(DI, sqrt(numStages_I)*DI_substage);
            tmax_Tg = min(ceil(gaminv(1-eps2, aa_Tg, bb_Tg)), 100);
            tvec_Tg = 0:data.dt:tmax_Tg;
            generationTimeCDF = gamcdf(tvec_Tg, aa_Tg, bb_Tg);
            generationTimePMF = generationTimeCDF(2:end)-generationTimeCDF(1:end-1);
            data.generationTimePMF = generationTimePMF/sum(generationTimePMF);
            data.meanTg = DI;
        end
        
        data.mu_Incub = log(median_Incub);
        data.sigma_Incub = sqrt(2*(log(mean_Incub)-data.mu_Incub));
        tmax_incubation = min(ceil(logninv(1-eps2, data.mu_Incub, data.sigma_Incub)), 100);
        tvec_incubation = 0:data.dt:tmax_incubation;
        incubationCDF = logncdf(tvec_incubation, data.mu_Incub, data.sigma_Incub);
        incubationPMF = incubationCDF(2:end)-incubationCDF(1:end-1);
        data.incubationPMF = incubationPMF/sum(incubationPMF);
        for selectedCountry=1:numel(country)            
            
            data.ageDist = ageDist(selectedCountry,:);
            data.numAgeGroups = numel(data.ageDist);
            data.contactMatrix = betaMatrix(:,:,:,selectedCountry);
            
            for policy=NONE:CLOSE_SECONDARY_ONLY
                
                data.policy = policy;
                
                [S, I, R, N, cumIncidence, cumOnset, growthRate, doublingTime, Rt] = transmissionModel(data);
                
                incidence = cumIncidence(:,2:end)-cumIncidence(:,1:end-1);
                R0(selectedCountry,policy,pathogen,R0_ii) = Rt(1);
                DT(selectedCountry,policy,pathogen,R0_ii) = doublingTime(10);
                
                [maxVal, maxIndex] = max(sum(I)./sum(N));
                peakPrevalence(selectedCountry,policy,pathogen,R0_ii) = maxVal;
                peakTime(selectedCountry,policy,pathogen,R0_ii) = maxIndex;
                
                [maxVal, maxIndex] = max(sum(I(fI_65,:))./sum(N(fI_65,:)));
                peakPrevalence65(selectedCountry,policy,pathogen,R0_ii) = maxVal;
                [maxVal, maxIndex] = max(sum(I(fI_18,:))./sum(N(fI_18,:)));
                peakPrevalence18(selectedCountry,policy,pathogen,R0_ii) = maxVal;
                
                [maxVal, maxIndex] = max(sum(incidence)./sum(N(:,2:end)));
                peakIncidence(selectedCountry,policy,pathogen,R0_ii) = maxVal;
                [maxVal, maxIndex] = max(sum(incidence(fI_65,:))./sum(N(fI_65,2:end)));
                peakIncidence65(selectedCountry,policy,pathogen,R0_ii) = maxVal;
                [maxVal, maxIndex] = max(sum(incidence(fI_18,:))./sum(N(fI_18,2:end)));
                peakIncidence18(selectedCountry,policy,pathogen,R0_ii) = maxVal;
                
                herdImmunityTime = find(Rt<1, 1);
                herdImmunityThres(selectedCountry,policy,pathogen,R0_ii) = sum(cumIncidence(:,herdImmunityTime))/sum(N(:,herdImmunityTime));
                
                IAR(selectedCountry,policy,pathogen,R0_ii) = sum(cumIncidence(:,end))/sum(N(:,end));
                IAR65(selectedCountry,policy,pathogen,R0_ii) = sum(cumIncidence(fI_65,end))/sum(N(fI_65,end));
                IAR18(selectedCountry,policy,pathogen,R0_ii) = sum(cumIncidence(fI_18,end))/sum(N(fI_18,end));
                
            end        
        end
        
        for m1=NONE:CLOSE_SECONDARY_ONLY
            for m2=NONE:CLOSE_SECONDARY_ONLY
                relativeReductionR0(:,pathogen,m1,m2,R0_ii) = 1-R0(:,m2,pathogen,R0_ii)./R0(:,m1,pathogen,R0_ii);
                delayPeakTime(:,pathogen,m1,m2,R0_ii) = peakTime(:,m2,pathogen,R0_ii)-peakTime(:,m1,pathogen,R0_ii);
                reductionPeakPrev(:,pathogen,m1,m2,R0_ii) = peakPrevalence(:,m1,pathogen,R0_ii)-peakPrevalence(:,m2,pathogen,R0_ii);
                relativeReductionPeakPrev(:,pathogen,m1,m2,R0_ii) = 1-peakPrevalence(:,m2,pathogen,R0_ii)./peakPrevalence(:,m1,pathogen,R0_ii);
                reductionPeakPrev65(:,pathogen,m1,m2,R0_ii) = peakPrevalence65(:,m1,pathogen,R0_ii)-peakPrevalence65(:,m2,pathogen,R0_ii);
                reductionPeakPrev18(:,pathogen,m1,m2,R0_ii) = peakPrevalence18(:,m1,pathogen,R0_ii)-peakPrevalence18(:,m2,pathogen,R0_ii);
                relativeReductionPeakPrev65(:,pathogen,m1,m2,R0_ii) = 1-peakPrevalence65(:,m2,pathogen,R0_ii)./peakPrevalence65(:,m1,pathogen,R0_ii);
                relativeReductionPeakPrev18(:,pathogen,m1,m2,R0_ii) = 1-peakPrevalence18(:,m2,pathogen,R0_ii)./peakPrevalence18(:,m1,pathogen,R0_ii);
                
                reductionPeakIncidence(:,pathogen,m1,m2,R0_ii) = peakIncidence(:,m1,pathogen,R0_ii)-peakIncidence(:,m2,pathogen,R0_ii);
                relativeReductionPeakIncidence(:,pathogen,m1,m2,R0_ii) = 1-peakIncidence(:,m2,pathogen,R0_ii)./peakIncidence(:,m1,pathogen,R0_ii);
                reductionPeakIncidence65(:,pathogen,m1,m2,R0_ii) = peakIncidence65(:,m1,pathogen,R0_ii)-peakIncidence65(:,m2,pathogen,R0_ii);
                reductionPeakIncidence18(:,pathogen,m1,m2,R0_ii) = peakIncidence18(:,m1,pathogen,R0_ii)-peakIncidence18(:,m2,pathogen,R0_ii);
                relativeReductionPeakIncidence65(:,pathogen,m1,m2,R0_ii) = 1-peakIncidence65(:,m2,pathogen,R0_ii)./peakIncidence65(:,m1,pathogen,R0_ii);
                relativeReductionPeakIncidence18(:,pathogen,m1,m2,R0_ii) = 1-peakIncidence18(:,m2,pathogen,R0_ii)./peakIncidence18(:,m1,pathogen,R0_ii);
                
                increaseDoublingTime(:,pathogen,m1,m2,R0_ii) = DT(:,m2,pathogen,R0_ii)-DT(:,m1,pathogen,R0_ii);
                reductionIAR(:,pathogen,m1,m2,R0_ii) = IAR(:,m1,pathogen,R0_ii)-IAR(:,m2,pathogen,R0_ii);
                reductionIAR65(:,pathogen,m1,m2,R0_ii) = IAR65(:,m1,pathogen,R0_ii)-IAR65(:,m2,pathogen,R0_ii);
                reductionIAR18(:,pathogen,m1,m2,R0_ii) = IAR18(:,m1,pathogen,R0_ii)-IAR18(:,m2,pathogen,R0_ii);
                relativeReductionIAR(:,pathogen,m1,m2,R0_ii) = 1-IAR(:,m2,pathogen,R0_ii)./IAR(:,m1,pathogen,R0_ii);
                relativeReductionIAR65(:,pathogen,m1,m2,R0_ii) = 1-IAR65(:,m2,pathogen,R0_ii)./IAR65(:,m1,pathogen,R0_ii);
                relativeReductionIAR18(:,pathogen,m1,m2,R0_ii) = 1-IAR18(:,m2,pathogen,R0_ii)./IAR18(:,m1,pathogen,R0_ii);
            end
        end
    end    
end


