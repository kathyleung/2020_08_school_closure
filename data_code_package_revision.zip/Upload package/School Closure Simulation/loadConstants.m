
NONE = 1; 
CLOSE_ALL_SCHOOLS = 2;
CLOSE_PRIMARY_ONLY = 3;
CLOSE_SECONDARY_ONLY = 4;
COMMUNITY_MATCHING = 5;

TOTAL = 1;
HOUSEHOLD = 2;
SCHOOL = 3;
WORKPLACE = 4;
COMMUNITY = 5;
PRIMARY_SCHOOL = 6;
SECONDARY_SCHOOL = 7;
numContactType = 7;

policyLabel = {'None', 'All', 'Primary', 'Secondary', 'Community'};