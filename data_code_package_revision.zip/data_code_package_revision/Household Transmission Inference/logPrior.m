function funval = logPrior(para, data)

ageVec = 0:100;
ageSuscepPartition = data.ageSuscepPartition;
nn = numel(ageSuscepPartition)-2;
ageSusceptibility = [para(1:nn) 1 1];

if (strcmp(data.interpolationMethod, 'pchip'))
    ageSusceptibilityRef = pchip(ageSuscepPartition, ageSusceptibility, ageVec);
else
    ageSusceptibilityRef = interp1(ageSuscepPartition, ageSusceptibility, ageVec);
end

pdfVal(5) = lognpdf(para(nn+2), -0.2120, 0.0970);
pdfVal(6) = lognpdf(para(nn+2), -0.0047, 0.0970);

%%%% Jing <20 vs >=60
a1 = 1:20;
a2 = 61:numel(ageVec);
xx = mean(ageSusceptibilityRef(a1))/mean(ageSusceptibilityRef(a2));
pdfVal(1) = lognpdf(xx, -1.5059, 0.3637);

%%%% Jing 20-59 vs >=60
a1 = 21:60;
a2 = 61:numel(ageVec);
xx = mean(ageSusceptibilityRef(a1))/mean(ageSusceptibilityRef(a2));
pdfVal(2) = lognpdf(xx, -0.4477, 0.2070);

%%%% HJ 0-14 vs 15-64
a1 = 1:15;
a2 = 16:65;
xx = mean(ageSusceptibilityRef(a1))/mean(ageSusceptibilityRef(a2));
pdfVal(3) = lognpdf(xx, -1.0788, 0.1817);

% %%%%% HJ >=65 vs 15-64
a1 = 66:numel(ageVec);
a2 = 16:65;
xx = mean(ageSusceptibilityRef(a1))/mean(ageSusceptibilityRef(a2));
pdfVal(4) = lognpdf(xx, 0.3805, 0.1374);

funval = sum(loge(pdfVal));
