clear all;
close all;

loadConstants

dir = 'Prem177/';
filename = [dir 'PopulationCountry.xlsx'];
P = importdata(filename);
P.textdata(1,:) = [];
countryNames = P.textdata(1:end,2);
countryPopSize = P.data(:,3+(1:21));
countryPopSize(:,16) = sum(countryPopSize(:,16:end),2);
countryPopSize(:,17:end) = [];
countryOutOfSchoolRate = P.data(:,27:28);

countryGDPpc = P.data(:,25);
for ii=1:numel(countryNames)
    if (strcmp(P.textdata(ii,end),'H'))
        countryIncomeGroup(ii) = 1;
    elseif (strcmp(P.textdata(ii,end),'UM'))
        countryIncomeGroup(ii) = 2;
    elseif (strcmp(P.textdata(ii,end),'LM'))
        countryIncomeGroup(ii) = 3;
    elseif (strcmp(P.textdata(ii,end),'L'))
        countryIncomeGroup(ii) = 4;
    end
end

for jj=1:2
    xx = countryOutOfSchoolRate(:,jj);
    for ii=1:4
        fI = find(countryIncomeGroup==ii);
        yy = xx(fI);
        meanOutOfSchoolRate(ii,jj) = mean(yy(~isnan(yy)));
        fI = find(countryIncomeGroup==ii & isnan(xx'));
        countryOutOfSchoolRate(fI,jj) = meanOutOfSchoolRate(ii,jj);
    end
end

numContactType = 7;
missingCountry = [];
errorCountry = [];
for ll=1:numContactType
    countryIndex = 1;
    if (ll==TOTAL)
        filename = [dir 'all.xlsx'];
    elseif (ll==HOUSEHOLD)
        filename = [dir 'home.xlsx'];
    elseif (ll==SCHOOL)
        filename = [dir 'school.xlsx'];
    elseif (ll==WORKPLACE)
        filename = [dir 'work.xlsx'];
    elseif (ll==COMMUNITY)
        filename = [dir 'others.xlsx'];
    elseif (ll==SCHOOL_PRIMARY)
        filename = [dir 'primary.xlsx'];
    elseif (ll==SCHOOL_SECONDARY)
        filename = [dir 'secondary.xlsx'];
    end
    
    [status, sheets] = xlsfinfo(filename);
    for ii=1:numel(sheets)
        [ii ll]
        sheets{ii}
        if (ll==1)
            countryFound(ii) = false;
            for jj=1:size(countryNames,1)
                if (strcmp(countryNames{jj}, sheets{ii}))
                    countryNames{jj}
                    countryFound(ii) = true;
                    break;
                end
            end
            if (countryFound(ii))
                ageDist(countryIndex,:) = countryPopSize(jj,:);
                country{countryIndex} = char(sheets{ii})
                GDPpc(countryIndex) = countryGDPpc(jj);
                outOfSchoolRate(countryIndex,:) = countryOutOfSchoolRate(jj,:);
                incomeGroup(countryIndex) = countryIncomeGroup(jj);
            else
                missingCountry{end+1} = sheets{ii};
            end
        end
        if (countryFound(ii))
            contactMatrix(:,:,ll,countryIndex) = readmatrix(filename, 'Sheet', sheets{ii});
            countryIndex = countryIndex+1;
        end
        if (any(isnan(countryOutOfSchoolRate(ii,:))))
            errorCountry{end+1} = sheets{ii};
        end
    end
end
missingCountry
errorCountry
for ii=1:177
    DD = contactMatrix(:,:,HOUSEHOLD,ii)+contactMatrix(:,:,SCHOOL,ii)+contactMatrix(:,:,WORKPLACE,ii)+contactMatrix(:,:,COMMUNITY,ii);
    AA = contactMatrix(:,:,TOTAL,ii);
    checkSum1(ii) = sum(sum(abs(DD-AA)))/sum(sum(AA));
    DD = contactMatrix(:,:,SCHOOL_PRIMARY,ii)+contactMatrix(:,:,SCHOOL_SECONDARY,ii);
    AA = contactMatrix(:,:,SCHOOL,ii);
    checkSum2(ii) =  sum(sum(abs(DD-AA)))/sum(sum(AA));
end
figure(1);
clf;
subplot(2,1,1);
bar(checkSum1);
ylabel('Delta for all contacts');
subplot(2,1,2);
bar(checkSum2);
ylabel('Delta for school contacts');
save([dir 'prem177.mat'])